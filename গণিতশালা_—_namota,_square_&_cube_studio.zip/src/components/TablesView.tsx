import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Lightbulb,
  Play,
} from 'lucide-react';
import {
  DigitStyle,
  Lang,
  formatNumber,
  getMentalMathBreakdown,
} from '../utils/math';

interface TablesViewProps {
  lang: Lang;
  digitStyle: DigitStyle;
  selectedTable: number;
  onSelectTable: (n: number) => void;
  practicedTables: number[];
  onPracticeTable: (tableNum: number, maxMultiplier: number) => void;
}

export const TablesView: React.FC<TablesViewProps> = ({
  lang,
  digitStyle,
  selectedTable,
  onSelectTable,
  practicedTables,
  onPracticeTable,
}) => {
  const [maxMultiplier, setMaxMultiplier] = useState<10 | 12 | 20>(10);
  const [activeRow, setActiveRow] = useState<number>(6);

  const f = (n: number | string) => formatNumber(n, digitStyle);

  const handleSelectTable = (n: number) => {
    const clamped = Math.max(1, Math.min(50, n));
    onSelectTable(clamped);
  };

  const breakdown = getMentalMathBreakdown(
    selectedTable,
    Math.min(activeRow, maxMultiplier),
    lang,
    digitStyle
  );

  const isPracticed = practicedTables.includes(selectedTable);
  const rows = Array.from({ length: maxMultiplier }, (_, i) => i + 1);

  return (
    <div className="max-w-2xl mx-auto">
      <section className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6">
        {/* Top Title + Primary Action Row */}
        <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
              <span>{lang === 'bn' ? 'নামতা' : 'Multiplication'}</span>
              <span aria-hidden="true">·</span>
              <span>
                {f(1)}–{f(50)}
              </span>
              {isPracticed && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-0.5 text-emerald-700 font-semibold">
                    <Check className="w-3 h-3" />
                    {lang === 'bn' ? 'অনুশীলিত' : 'Practiced'}
                  </span>
                </>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-0.5 truncate">
              {lang === 'bn'
                ? `${f(selectedTable)}-এর নামতা`
                : `Table of ${f(selectedTable)}`}
            </h1>
          </div>

          <button
            type="button"
            onClick={() => onPracticeTable(selectedTable, maxMultiplier)}
            className="min-h-[40px] px-3.5 sm:px-4 inline-flex items-center gap-1.5 rounded-xl bg-sky-700 hover:bg-sky-800 active:scale-[0.98] text-white text-xs sm:text-sm font-semibold transition-all whitespace-nowrap shrink-0"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'প্রশ্ন-উত্তর' : 'Start Q&A'}</span>
          </button>
        </div>

        {/* Clean Single-Row Table Picker + Multiplier Depth */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => handleSelectTable(selectedTable - 1)}
              disabled={selectedTable <= 1}
              aria-label={lang === 'bn' ? 'আগের নামতা' : 'Previous table'}
              className="h-10 w-10 inline-flex items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 active:scale-95 disabled:opacity-35 disabled:cursor-not-allowed transition-all shrink-0"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <select
              aria-label={lang === 'bn' ? 'নামতা নির্বাচন' : 'Select Table'}
              value={selectedTable}
              onChange={(e) => handleSelectTable(Number(e.target.value))}
              className="flex-1 sm:w-44 h-10 px-3 rounded-xl border border-slate-200 bg-slate-50 text-sm font-semibold text-slate-900 tabular-math focus:bg-white focus:border-sky-600 focus:outline-none"
            >
              {Array.from({ length: 50 }, (_, i) => i + 1).map((num) => (
                <option key={num} value={num}>
                  {lang === 'bn' ? `${f(num)}-এর নামতা` : `Table ${f(num)}`}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => handleSelectTable(selectedTable + 1)}
              disabled={selectedTable >= 50}
              aria-label={lang === 'bn' ? 'পরের নামতা' : 'Next table'}
              className="h-10 w-10 inline-flex items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 active:scale-95 disabled:opacity-35 disabled:cursor-not-allowed transition-all shrink-0"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-3 sm:flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            {([10, 12, 20] as const).map((limit) => (
              <button
                key={limit}
                type="button"
                onClick={() => {
                  setMaxMultiplier(limit);
                  if (activeRow > limit) setActiveRow(limit);
                }}
                className={`py-1.5 px-3 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  maxMultiplier === limit
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {`×${f(1)}–${f(limit)}`}
              </button>
            ))}
          </div>
        </div>

        {/* Crisp Scannable Multiplication List */}
        <div
          className={`grid gap-1.5 pt-3.5 ${
            maxMultiplier > 10 ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1'
          }`}
        >
          {rows.map((m) => {
            const product = selectedTable * m;
            const isSelected = activeRow === m;

            return (
              <button
                key={m}
                type="button"
                onClick={() => setActiveRow(m)}
                className={`w-full min-h-[46px] flex items-center justify-between px-4 py-2.5 rounded-xl border text-left transition-colors ${
                  isSelected
                    ? 'bg-sky-50/80 border-sky-300'
                    : 'bg-slate-50/50 border-slate-200/75 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2.5 text-[15px] sm:text-base font-medium tabular-math text-slate-600">
                  <span className="w-7 text-right font-semibold text-slate-800">
                    {f(selectedTable)}
                  </span>
                  <span className="text-slate-400 text-sm">×</span>
                  <span className="w-7 text-left font-semibold text-slate-700">
                    {f(m)}
                  </span>
                  <span className="text-slate-400 text-sm">=</span>
                </div>

                <span className="text-xl sm:text-2xl font-bold text-slate-900 tabular-math">
                  {f(product)}
                </span>
              </button>
            );
          })}
        </div>

        {/* Compact Mental Math Tip */}
        <div className="mt-4 pt-4 border-t border-slate-200/80">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-sky-800 mb-1">
            <Lightbulb className="w-3.5 h-3.5 shrink-0" />
            <span>
              {lang === 'bn'
                ? 'সহজ হিসাব (যেকোনো সারিতে ট্যাপ করুন)'
                : 'Mental Math Tip (tap any row)'}
            </span>
          </div>
          <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5">
            <p className="text-sm font-semibold text-slate-900 tabular-math">
              {breakdown.formula}
            </p>
            <p className="text-xs font-semibold text-sky-700 tabular-math">
              {breakdown.steps}
            </p>
          </div>
          <p className="text-xs text-slate-600 mt-1 leading-relaxed">
            {breakdown.tip}
          </p>
        </div>
      </section>
    </div>
  );
};
