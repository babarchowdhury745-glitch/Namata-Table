import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Delete,
  Lightbulb,
  ListOrdered,
  Play,
  RotateCcw,
  Settings2,
  Shuffle,
  XCircle,
} from 'lucide-react';
import {
  DigitStyle,
  Lang,
  MathQuestion,
  QuizRecord,
  buildPracticeQuestions,
  buildQuizQuestions,
  formatNumber,
  getMentalMathBreakdown,
  getSquareTrick,
  normalizeDigits,
  saveQuizRecord,
} from '../utils/math';

export type QATopic = 'table' | 'square' | 'cube' | 'mixed';

export interface QAPreset {
  topic: QATopic;
  tables?: number[];
  maxMultiplier?: number;
  rangeMin?: number;
  rangeMax?: number;
  autoStart?: boolean;
  nonce: number;
}

interface QAViewProps {
  lang: Lang;
  digitStyle: DigitStyle;
  preset: QAPreset | null;
  onMarkTablesPracticed: (tables: number[]) => void;
}

interface QuestionSummaryLog {
  question: MathQuestion;
  wrongTries: number;
  wrongAnswers: number[];
}

export const QAView: React.FC<QAViewProps> = ({
  lang,
  digitStyle,
  preset,
  onMarkTablesPracticed,
}) => {
  const [phase, setPhase] = useState<'setup' | 'active' | 'summary'>('setup');

  // Configuration state
  const [topic, setTopic] = useState<QATopic>('table');
  const [selectedTables, setSelectedTables] = useState<number[]>([12]);
  const [multiSelect, setMultiSelect] = useState(false);
  const [maxMultiplier, setMaxMultiplier] = useState<number>(10);
  const [rangeMin, setRangeMin] = useState<number>(1);
  const [rangeMax, setRangeMax] = useState<number>(20);
  const [mixedCount, setMixedCount] = useState<10 | 20 | 30>(20);
  const [order, setOrder] = useState<'sequential' | 'shuffled'>('shuffled');
  const [answerMode, setAnswerMode] = useState<'type' | 'mcq'>('type');

  // Active Q&A state (strict: cannot advance until correct!)
  const [questions, setQuestions] = useState<MathQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [typedValue, setTypedValue] = useState('');
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [currentWrongTries, setCurrentWrongTries] = useState(0);
  const [currentWrongAnswers, setCurrentWrongAnswers] = useState<number[]>([]);
  const [eliminatedMcq, setEliminatedMcq] = useState<number[]>([]);
  const [statusBanner, setStatusBanner] = useState<{
    type: 'wrong' | 'correct';
    message: string;
  } | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [advancing, setAdvancing] = useState(false);
  const [logs, setLogs] = useState<QuestionSummaryLog[]>([]);
  const sessionStartRef = useRef<number>(Date.now());
  const advanceTimerRef = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const f = (n: number | string, commas = false) =>
    formatNumber(n, digitStyle, commas);

  const clearPendingAdvance = () => {
    if (advanceTimerRef.current !== null) {
      window.clearTimeout(advanceTimerRef.current);
      advanceTimerRef.current = null;
    }
  };

  useEffect(() => {
    return () => clearPendingAdvance();
  }, []);

  const launchSession = (params: {
    nextTopic: QATopic;
    nextTables: number[];
    nextMaxMult: number;
    nextMin: number;
    nextMax: number;
    nextOrder: 'sequential' | 'shuffled';
    nextMixedCount: number;
    customList?: MathQuestion[];
  }) => {
    clearPendingAdvance();
    const {
      nextTopic,
      nextTables,
      nextMaxMult,
      nextMin,
      nextMax,
      nextOrder,
      nextMixedCount,
      customList,
    } = params;

    let list: MathQuestion[];
    if (customList && customList.length > 0) {
      list = customList;
    } else if (nextTopic === 'mixed') {
      list = buildQuizQuestions({
        topic: 'mixed',
        tableMin: 2,
        tableMax: 25,
        maxMultiplier: nextMaxMult,
        squareMin: 1,
        squareMax: 30,
        cubeMin: 1,
        cubeMax: 20,
        count: nextMixedCount,
      });
    } else {
      const safeTables = nextTables.length > 0 ? nextTables : [12];
      list = buildPracticeQuestions({
        kind: nextTopic,
        tables: safeTables,
        maxMultiplier: nextMaxMult,
        powerMin: nextMin,
        powerMax: nextMax,
        order: nextOrder,
      });
    }

    setQuestions(list);
    setCurrentIndex(0);
    setTypedValue('');
    setCorrectCount(0);
    setWrongCount(0);
    setCurrentWrongTries(0);
    setCurrentWrongAnswers([]);
    setEliminatedMcq([]);
    setStatusBanner(null);
    setShowHint(false);
    setAdvancing(false);
    setLogs([]);
    sessionStartRef.current = Date.now();
    setPhase('active');
  };

  // Handle preset navigation from Namota, Square, or Cube tabs
  useEffect(() => {
    if (!preset) return;
    const nextTopic = preset.topic;
    const nextTables = preset.tables ?? selectedTables;
    const nextMaxMult = preset.maxMultiplier ?? maxMultiplier;
    const nextMin = preset.rangeMin ?? rangeMin;
    const nextMax = preset.rangeMax ?? rangeMax;

    setTopic(nextTopic);
    if (preset.tables) {
      setSelectedTables(preset.tables);
      setMultiSelect(preset.tables.length > 1);
    }
    if (preset.maxMultiplier) setMaxMultiplier(preset.maxMultiplier);
    if (preset.rangeMin !== undefined) setRangeMin(preset.rangeMin);
    if (preset.rangeMax !== undefined) setRangeMax(preset.rangeMax);

    if (preset.autoStart) {
      launchSession({
        nextTopic,
        nextTables,
        nextMaxMult,
        nextMin,
        nextMax,
        nextOrder: order,
        nextMixedCount: mixedCount,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preset?.nonce]);

  useEffect(() => {
    if (phase === 'active' && answerMode === 'type' && !advancing) {
      inputRef.current?.focus();
    }
  }, [phase, currentIndex, answerMode, advancing]);

  const currentQuestion = questions[currentIndex];

  const renderPrompt = (q: MathQuestion) => {
    if (q.kind === 'table' && q.b !== undefined) {
      return `${f(q.a)} × ${f(q.b)}`;
    }
    if (q.kind === 'square') return `${f(q.a)}²`;
    return `${f(q.a)}³`;
  };

  const getHintText = (q: MathQuestion) => {
    if (q.kind === 'table' && q.b !== undefined) {
      const info = getMentalMathBreakdown(q.a, q.b, lang, digitStyle);
      return `${info.formula.split('=')[0].trim()} = ${info.steps.split('=')[0].trim()}`;
    }
    if (q.kind === 'square') {
      return getSquareTrick(q.a, lang, digitStyle).replace(/=[^=]*$/, '');
    }
    return lang === 'bn'
      ? `${f(q.a)}² = ${f(q.a * q.a, true)}, এবার একে আবার ${f(q.a)} দিয়ে গুণ করুন।`
      : `First ${f(q.a)}² = ${f(q.a * q.a, true)}, then multiply by ${f(q.a)}.`;
  };

  const finishSession = (
    finalLogs: QuestionSummaryLog[],
    finalCorrect: number,
    finalWrong: number
  ) => {
    const totalAttempts = finalCorrect + finalWrong;
    const accuracy =
      totalAttempts > 0 ? Math.round((finalCorrect / totalAttempts) * 100) : 100;
    const elapsedTotal = Math.max(1, (Date.now() - sessionStartRef.current) / 1000);
    const avgSeconds = Number(
      (elapsedTotal / Math.max(1, finalLogs.length)).toFixed(1)
    );

    const record: QuizRecord = {
      id: `qa-${Date.now()}`,
      dateISO: new Date().toISOString(),
      topic,
      mode: answerMode,
      total: finalLogs.length,
      correct: finalLogs.filter((l) => l.wrongTries === 0).length,
      accuracy,
      avgSeconds,
      rangeLabel:
        topic === 'table'
          ? selectedTables.join(',')
          : `${rangeMin}–${rangeMax}`,
    };

    saveQuizRecord(record);
    if (topic === 'table') {
      onMarkTablesPracticed(selectedTables);
    }
    setPhase('summary');
  };

  const handleAnswerCheck = (numericVal: number) => {
    if (!currentQuestion || advancing) return;

    if (numericVal === currentQuestion.answer) {
      // CORRECT -> Increment right count, show green confirmation, advance to next!
      const nextCorrect = correctCount + 1;
      setCorrectCount(nextCorrect);
      setAdvancing(true);
      setStatusBanner({
        type: 'correct',
        message:
          lang === 'bn'
            ? `সঠিক উত্তর! ${renderPrompt(currentQuestion)} = ${f(currentQuestion.answer, true)}`
            : `Correct! ${renderPrompt(currentQuestion)} = ${f(currentQuestion.answer, true)}`,
      });

      const completedLog: QuestionSummaryLog = {
        question: currentQuestion,
        wrongTries: currentWrongTries,
        wrongAnswers: currentWrongAnswers,
      };
      const updatedLogs = [...logs, completedLog];
      setLogs(updatedLogs);

      advanceTimerRef.current = window.setTimeout(() => {
        if (currentIndex + 1 >= questions.length) {
          finishSession(updatedLogs, nextCorrect, wrongCount);
        } else {
          setCurrentIndex((i) => i + 1);
          setTypedValue('');
          setCurrentWrongTries(0);
          setCurrentWrongAnswers([]);
          setEliminatedMcq([]);
          setStatusBanner(null);
          setShowHint(false);
          setAdvancing(false);
        }
      }, 550);
    } else {
      // WRONG -> DO NOT advance! Increment wrong count and keep asking until right!
      setWrongCount((w) => w + 1);
      setCurrentWrongTries((t) => t + 1);
      setCurrentWrongAnswers((prev) => [...prev, numericVal]);
      if (answerMode === 'mcq') {
        setEliminatedMcq((prev) =>
          prev.includes(numericVal) ? prev : [...prev, numericVal]
        );
      } else {
        setTypedValue('');
        inputRef.current?.focus();
      }
      setStatusBanner({
        type: 'wrong',
        message:
          lang === 'bn'
            ? `${f(numericVal, true)} ভুল উত্তর — সঠিক উত্তর না দেওয়া পর্যন্ত পরের প্রশ্ন আসবে না। আবার চেষ্টা করুন!`
            : `${f(numericVal, true)} is wrong — enter the correct answer to move to the next question.`,
      });
    }
  };

  const handleTypeSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (advancing) return;
    const cleaned = normalizeDigits(typedValue);
    if (!cleaned) return;
    handleAnswerCheck(parseInt(cleaned, 10));
  };

  const handleKeypad = (key: string) => {
    if (advancing) return;
    if (key === 'back') {
      setTypedValue((v) => v.slice(0, -1));
      return;
    }
    if (key === 'clear') {
      setTypedValue('');
      return;
    }
    if (typedValue.length < 7) {
      setTypedValue((v) => v + key);
    }
  };

  const handleTableToggle = (num: number) => {
    if (multiSelect) {
      setSelectedTables((prev) => {
        if (prev.includes(num)) {
          return prev.length > 1 ? prev.filter((x) => x !== num) : prev;
        }
        return [...prev, num].sort((a, b) => a - b);
      });
    } else {
      setSelectedTables([num]);
    }
  };

  const topicName = (t: QATopic) => {
    if (lang === 'bn') {
      if (t === 'table') return 'নামতা';
      if (t === 'square') return 'বর্গ';
      if (t === 'cube') return 'ঘন';
      return 'সব মিলিয়ে';
    }
    if (t === 'table') return 'Tables';
    if (t === 'square') return 'Squares';
    if (t === 'cube') return 'Cubes';
    return 'Mixed';
  };

  // ==================== SETUP PHASE ====================
  if (phase === 'setup') {
    return (
      <div className="max-w-2xl mx-auto">
        <section className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-5">
          <div className="pb-4 border-b border-slate-100">
            <div className="text-[11px] font-medium text-slate-500">
              {lang === 'bn'
                ? 'সঠিক উত্তর দিলেই পরের প্রশ্ন আসবে'
                : 'Correct answer required to advance'}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-0.5">
              {lang === 'bn' ? 'প্রশ্ন-উত্তর অনুশীলন' : 'Interactive Q&A Practice'}
            </h1>
          </div>

          {/* Choose Topic */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              {lang === 'bn' ? 'কোন বিষয়ের প্রশ্ন চান?' : 'Choose Topic'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['table', 'square', 'cube', 'mixed'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTopic(t)}
                  className={`min-h-[44px] px-3 rounded-xl border text-sm font-medium transition-colors whitespace-nowrap ${
                    topic === t
                      ? 'bg-sky-700 border-sky-700 text-white'
                      : 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  {topicName(t)}
                </button>
              ))}
            </div>
          </div>

          {/* Topic Specific Selector */}
          {topic === 'table' && (
            <div className="space-y-4 pt-2 border-t border-slate-100">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-700">
                  {lang === 'bn'
                    ? `নির্বাচিত নামতা: ${selectedTables.map((n) => f(n)).join(', ')}`
                    : `Selected table(s): ${selectedTables.map((n) => f(n)).join(', ')}`}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const next = !multiSelect;
                    setMultiSelect(next);
                    if (!next && selectedTables.length > 1) {
                      setSelectedTables([selectedTables[0]]);
                    }
                  }}
                  className="text-xs font-medium text-sky-700 hover:text-sky-900 underline underline-offset-4"
                >
                  {multiSelect
                    ? lang === 'bn'
                      ? 'একটি নামতা বাছাই'
                      : 'Pick Single Table'
                    : lang === 'bn'
                      ? 'একাধিক নামতা বাছাই'
                      : 'Pick Multiple Tables'}
                </button>
              </div>

              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-slate-600">
                  {lang === 'bn' ? 'গুণনীয়ক সীমা' : 'Multiply up to'}
                </span>
                <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl shrink-0">
                  {[10, 12, 20].map((lim) => (
                    <button
                      key={lim}
                      type="button"
                      onClick={() => setMaxMultiplier(lim)}
                      className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                        maxMultiplier === lim
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600'
                      }`}
                    >
                      ×{f(lim)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5 max-h-52 overflow-y-auto pr-0.5">
                {Array.from({ length: 50 }, (_, i) => i + 1).map((num) => {
                  const active = selectedTables.includes(num);
                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleTableToggle(num)}
                      className={`min-h-[40px] rounded-lg text-xs font-semibold tabular-math transition-colors ${
                        active
                          ? 'bg-sky-700 text-white'
                          : 'bg-slate-50 border border-slate-200/80 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {f(num)}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {(topic === 'square' || topic === 'cube') && (
            <div className="space-y-4 pt-2 border-t border-slate-100">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">
                    {lang === 'bn'
                      ? `শুরু (${f(1)}–${f(100)})`
                      : `From (${f(1)}–${f(100)})`}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={rangeMin}
                    onChange={(e) =>
                      setRangeMin(
                        Math.max(1, Math.min(100, Number(e.target.value) || 1))
                      )
                    }
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 bg-slate-50 text-sm font-medium tabular-math focus:bg-white focus:border-sky-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">
                    {lang === 'bn'
                      ? `শেষ (${f(1)}–${f(100)})`
                      : `To (${f(1)}–${f(100)})`}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={rangeMax}
                    onChange={(e) =>
                      setRangeMax(
                        Math.max(1, Math.min(100, Number(e.target.value) || 1))
                      )
                    }
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 bg-slate-50 text-sm font-medium tabular-math focus:bg-white focus:border-sky-600 focus:outline-none"
                  />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {[
                  { min: 1, max: 15 },
                  { min: 1, max: 25 },
                  { min: 26, max: 50 },
                  { min: 51, max: 100 },
                ].map((r) => (
                  <button
                    key={`${r.min}-${r.max}`}
                    type="button"
                    onClick={() => {
                      setRangeMin(r.min);
                      setRangeMax(r.max);
                    }}
                    className="min-h-[36px] px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-medium text-slate-700 transition-colors"
                  >
                    {f(r.min)}–{f(r.max)}
                  </button>
                ))}
              </div>
            </div>
          )}

          {topic === 'mixed' && (
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <span className="block text-xs font-medium text-slate-600">
                {lang === 'bn'
                  ? 'মোট কতটি প্রশ্ন? (নামতা + বর্গ + ঘন)'
                  : 'Number of Mixed Questions'}
              </span>
              <div className="flex gap-1 p-1 bg-slate-100 rounded-xl max-w-xs">
                {([10, 20, 30] as const).map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => setMixedCount(cnt)}
                    className={`flex-1 py-2 text-xs font-medium rounded-lg tabular-math transition-colors ${
                      mixedCount === cnt
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600'
                    }`}
                  >
                    {f(cnt)}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Answer Mode & Order */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-200">
            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-2">
                {lang === 'bn' ? 'উত্তর দেওয়ার মাধ্যম' : 'Answer Input'}
              </span>
              <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setAnswerMode('type')}
                  className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
                    answerMode === 'type'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  {lang === 'bn' ? 'লিখে উত্তর' : 'Type Answer'}
                </button>
                <button
                  type="button"
                  onClick={() => setAnswerMode('mcq')}
                  className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
                    answerMode === 'mcq'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  {lang === 'bn' ? `${f(4)}টি অপশন` : `${f(4)} Options`}
                </button>
              </div>
            </div>

            {topic !== 'mixed' && (
              <div>
                <span className="block text-xs font-semibold text-slate-700 mb-2">
                  {lang === 'bn' ? 'প্রশ্নের ক্রম' : 'Question Order'}
                </span>
                <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setOrder('sequential')}
                    className={`flex-1 py-2 text-xs font-medium rounded-lg inline-flex items-center justify-center gap-1.5 transition-colors ${
                      order === 'sequential'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600'
                    }`}
                  >
                    <ListOrdered className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'ক্রমানুসারে' : 'In Order'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrder('shuffled')}
                    className={`flex-1 py-2 text-xs font-medium rounded-lg inline-flex items-center justify-center gap-1.5 transition-colors ${
                      order === 'shuffled'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600'
                    }`}
                  >
                    <Shuffle className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'এলোমেলো' : 'Shuffled'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() =>
              launchSession({
                nextTopic: topic,
                nextTables: selectedTables,
                nextMaxMult: maxMultiplier,
                nextMin: rangeMin,
                nextMax: rangeMax,
                nextOrder: order,
                nextMixedCount: mixedCount,
              })
            }
            className="w-full sm:w-auto min-h-[48px] px-7 rounded-xl bg-sky-700 hover:bg-sky-800 active:scale-[0.98] text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-all"
          >
            <Play className="w-4 h-4" />
            <span>{lang === 'bn' ? 'প্রশ্ন শুরু করুন' : 'Start Questions'}</span>
          </button>
        </section>
      </div>
    );
  }

  // ==================== ACTIVE Q&A PHASE ====================
  if (phase === 'active' && currentQuestion) {
    return (
      <section className="max-w-lg mx-auto bg-white border border-slate-200 rounded-2xl p-4 sm:p-6">
        {/* Stacked Mobile-Friendly Live Scoreboard */}
        <div className="grid grid-cols-3 gap-2 mb-3.5">
          <div className="px-2.5 py-2 rounded-xl bg-emerald-50 border border-emerald-200/80 text-center">
            <div className="inline-flex items-center justify-center gap-1 text-[11px] font-medium text-emerald-800">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span>{lang === 'bn' ? 'সঠিক' : 'Right'}</span>
            </div>
            <div className="text-xl font-bold text-emerald-800 tabular-math leading-tight mt-0.5">
              {f(correctCount)}
            </div>
          </div>

          <div className="px-2.5 py-2 rounded-xl bg-rose-50 border border-rose-200/80 text-center">
            <div className="inline-flex items-center justify-center gap-1 text-[11px] font-medium text-rose-800">
              <XCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{lang === 'bn' ? 'ভুল' : 'Wrong'}</span>
            </div>
            <div className="text-xl font-bold text-rose-800 tabular-math leading-tight mt-0.5">
              {f(wrongCount)}
            </div>
          </div>

          <div className="px-2.5 py-2 rounded-xl bg-slate-50 border border-slate-200/80 text-center">
            <div className="text-[11px] font-medium text-slate-500">
              {lang === 'bn' ? 'প্রশ্ন' : 'Progress'}
            </div>
            <div className="text-base sm:text-lg font-bold text-slate-900 tabular-math leading-tight mt-1">
              {f(currentIndex + 1)}/{f(questions.length)}
            </div>
          </div>
        </div>

        {/* Progress Line + Change Setup */}
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-sky-600 transition-all duration-200"
              style={{
                width: `${((currentIndex + (advancing ? 1 : 0)) / Math.max(1, questions.length)) * 100}%`,
              }}
            />
          </div>
          <button
            type="button"
            onClick={() => {
              clearPendingAdvance();
              setPhase('setup');
            }}
            className="text-[11px] font-semibold text-slate-500 hover:text-slate-900 inline-flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'বিষয় বদলান' : 'Setup'}</span>
          </button>
        </div>

        {/* Hero Question Equation */}
        <div className="text-center py-4 sm:py-6">
          <div className="text-[11px] font-medium text-slate-500 mb-1.5">
            {currentQuestion.kind === 'table'
              ? lang === 'bn'
                ? 'সঠিক গুণফল লিখুন'
                : 'Enter the product'
              : currentQuestion.kind === 'square'
                ? lang === 'bn'
                  ? 'সঠিক বর্গ লিখুন'
                  : 'Enter the square'
                : lang === 'bn'
                  ? 'সঠিক ঘন লিখুন'
                  : 'Enter the cube'}
          </div>
          <div className="text-4xl sm:text-5xl font-bold text-slate-900 tracking-tight tabular-math">
            {renderPrompt(currentQuestion)}{' '}
            <span className="text-slate-400 font-normal">=</span>{' '}
            <span className={advancing ? 'text-emerald-700' : 'text-sky-700'}>
              {advancing
                ? f(currentQuestion.answer, true)
                : typedValue
                  ? f(typedValue)
                  : '?'}
            </span>
          </div>

          <div className="mt-2.5 min-h-[24px]">
            {showHint ? (
              <p className="text-xs text-sky-800 bg-sky-50 inline-block px-3 py-1 rounded-lg tabular-math">
                {getHintText(currentQuestion)}
              </p>
            ) : (
              <button
                type="button"
                onClick={() => setShowHint(true)}
                className="text-[11px] font-semibold text-slate-500 hover:text-sky-700 inline-flex items-center gap-1"
              >
                <Lightbulb className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'ইঙ্গিত দেখুন' : 'Need a hint?'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Compact Status Banner */}
        {statusBanner && (
          <div
            role="alert"
            className={`mb-4 px-3.5 py-2.5 rounded-xl border flex items-center gap-2 text-xs sm:text-sm font-medium ${
              statusBanner.type === 'correct'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            {statusBanner.type === 'correct' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-700 shrink-0" />
            )}
            <span>{statusBanner.message}</span>
          </div>
        )}

        {/* Answer Area */}
        {answerMode === 'type' ? (
          <div className="max-w-md mx-auto space-y-3.5">
            <form onSubmit={handleTypeSubmit} className="flex gap-2">
              <input
                ref={inputRef}
                type="text"
                inputMode="numeric"
                value={typedValue}
                disabled={advancing}
                onChange={(e) => setTypedValue(e.target.value)}
                placeholder={
                  lang === 'bn' ? 'সঠিক উত্তর লিখুন...' : 'Type your answer...'
                }
                className="flex-1 h-12 px-4 rounded-xl border border-slate-300 bg-white text-lg font-semibold text-center tabular-math focus:border-sky-600 focus:outline-none disabled:bg-slate-50"
              />
              <button
                type="submit"
                disabled={advancing}
                className="h-12 px-6 rounded-xl bg-sky-700 hover:bg-sky-800 active:scale-[0.98] text-white text-sm font-semibold transition-all whitespace-nowrap shrink-0 disabled:opacity-60"
              >
                {lang === 'bn' ? 'জমা দিন' : 'Check'}
              </button>
            </form>

            {/* Mobile-Friendly On-Screen Numpad */}
            <div className="grid grid-cols-3 gap-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
                <button
                  key={d}
                  type="button"
                  disabled={advancing}
                  onClick={() => handleKeypad(d)}
                  className="min-h-[48px] rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 active:scale-95 text-lg font-semibold text-slate-800 tabular-math transition-all"
                >
                  {f(d)}
                </button>
              ))}
              <button
                type="button"
                disabled={advancing}
                onClick={() => handleKeypad('clear')}
                className="min-h-[48px] rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 active:scale-95 text-xs font-semibold text-slate-600 transition-all"
              >
                {lang === 'bn' ? 'মুছুন' : 'Clear'}
              </button>
              <button
                type="button"
                disabled={advancing}
                onClick={() => handleKeypad('0')}
                className="min-h-[48px] rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 active:scale-95 text-lg font-semibold text-slate-800 tabular-math transition-all"
              >
                {f('0')}
              </button>
              <button
                type="button"
                disabled={advancing}
                onClick={() => handleKeypad('back')}
                aria-label={lang === 'bn' ? 'পেছনে মুছুন' : 'Backspace'}
                className="min-h-[48px] rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 active:scale-95 text-slate-700 inline-flex items-center justify-center transition-all"
              >
                <Delete className="w-5 h-5" />
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 max-w-lg mx-auto">
            {currentQuestion.options.map((opt) => {
              const isEliminated = eliminatedMcq.includes(opt);
              const isRightSelected =
                advancing && opt === currentQuestion.answer;

              let cls =
                'bg-slate-50 border-slate-200 text-slate-900 hover:bg-slate-100 hover:border-slate-300';
              if (isRightSelected) {
                cls = 'bg-emerald-50 border-emerald-400 text-emerald-900';
              } else if (isEliminated) {
                cls =
                  'bg-rose-50 border-rose-300 text-rose-400 line-through cursor-not-allowed';
              }

              return (
                <button
                  key={opt}
                  type="button"
                  disabled={advancing || isEliminated}
                  onClick={() => handleAnswerCheck(opt)}
                  className={`min-h-[56px] rounded-xl border text-lg font-bold tabular-math active:scale-[0.98] transition-all ${cls}`}
                >
                  {f(opt, true)}
                </button>
              );
            })}
          </div>
        )}
      </section>
    );
  }

  // ==================== SUMMARY PHASE ====================
  const questionsWithMistakes = logs.filter((l) => l.wrongTries > 0);
  const firstTryRight = logs.filter((l) => l.wrongTries === 0).length;
  const totalAttempts = correctCount + wrongCount;
  const accuracy =
    totalAttempts > 0 ? Math.round((correctCount / totalAttempts) * 100) : 100;
  const singleTable =
    topic === 'table' && selectedTables.length === 1 ? selectedTables[0] : null;

  return (
    <section className="max-w-2xl mx-auto bg-white border border-slate-200 rounded-2xl p-5 sm:p-7 space-y-6">
      <div className="pb-4 border-b border-slate-100">
        <div className="text-[11px] font-medium text-slate-500 mb-0.5">
          {lang === 'bn' ? 'প্রশ্ন-উত্তর সম্পন্ন!' : 'Session Complete!'}
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
          {lang === 'bn'
            ? `মোট সঠিক: ${f(correctCount)} টি · মোট ভুল: ${f(wrongCount)} বার`
            : `Total Right: ${f(correctCount)} · Total Wrong: ${f(wrongCount)}`}
        </h1>
      </div>

      {/* Summary Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200/80">
          <div className="text-[11px] text-emerald-800 font-medium">
            {lang === 'bn' ? 'মোট সঠিক' : 'Total Right'}
          </div>
          <div className="text-2xl font-bold text-emerald-800 mt-0.5 tabular-math">
            {f(correctCount)}
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200/80">
          <div className="text-[11px] text-rose-800 font-medium">
            {lang === 'bn' ? 'মোট ভুল' : 'Total Wrong'}
          </div>
          <div className="text-2xl font-bold text-rose-800 mt-0.5 tabular-math">
            {f(wrongCount)}
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="text-[11px] text-slate-600 font-medium">
            {lang === 'bn' ? 'প্রথম চেষ্টায় সঠিক' : 'First-Try Right'}
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-0.5 tabular-math">
            {f(firstTryRight)}/{f(logs.length)}
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="text-[11px] text-slate-600 font-medium">
            {lang === 'bn' ? 'নির্ভুলতা' : 'Accuracy'}
          </div>
          <div className="text-2xl font-bold text-sky-800 mt-0.5 tabular-math">
            {f(accuracy)}%
          </div>
        </div>
      </div>

      {/* Mistakes Review */}
      {questionsWithMistakes.length > 0 ? (
        <div>
          <h2 className="text-sm font-semibold text-slate-900 mb-3">
            {lang === 'bn'
              ? 'যে প্রশ্নগুলোতে ভুল হয়েছিল'
              : 'Questions That Needed Extra Tries'}
          </h2>
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {questionsWithMistakes.map((entry, idx) => (
              <div
                key={`${entry.question.id}-${idx}`}
                className="px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-sm bg-slate-50/50"
              >
                <span className="font-semibold text-slate-900 tabular-math">
                  {renderPrompt(entry.question)} ={' '}
                  <span className="text-emerald-700">
                    {f(entry.question.answer, true)}
                  </span>
                </span>
                <span className="text-xs font-medium text-rose-700 tabular-bengali">
                  {lang === 'bn'
                    ? `${f(entry.wrongTries)} বার ভুল`
                    : `${f(entry.wrongTries)} wrong ${entry.wrongTries === 1 ? 'try' : 'tries'}`}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-sm font-medium text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
          <span>
            {lang === 'bn'
              ? 'দারুণ! কোনো ভুল ছাড়াই সবগুলো প্রশ্নের সঠিক উত্তর দিয়েছেন।'
              : 'Perfect! You answered every question right on the first try.'}
          </span>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        {questionsWithMistakes.length > 0 && (
          <button
            type="button"
            onClick={() =>
              launchSession({
                nextTopic: topic,
                nextTables: selectedTables,
                nextMaxMult: maxMultiplier,
                nextMin: rangeMin,
                nextMax: rangeMax,
                nextOrder: 'shuffled',
                nextMixedCount: mixedCount,
                customList: questionsWithMistakes.map((m) => m.question),
              })
            }
            className="min-h-[44px] px-5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            <span>
              {lang === 'bn'
                ? 'শুধু ভুল প্রশ্নগুলো আবার করুন'
                : 'Retry Missed Questions'}
            </span>
          </button>
        )}

        <button
          type="button"
          onClick={() =>
            launchSession({
              nextTopic: topic,
              nextTables: selectedTables,
              nextMaxMult: maxMultiplier,
              nextMin: rangeMin,
              nextMax: rangeMax,
              nextOrder: order,
              nextMixedCount: mixedCount,
            })
          }
          className="min-h-[44px] px-5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{lang === 'bn' ? 'আবার শুরু করুন' : 'Play Again'}</span>
        </button>

        {singleTable !== null && singleTable < 50 && (
          <button
            type="button"
            onClick={() => {
              const nextT = [singleTable + 1];
              setSelectedTables(nextT);
              launchSession({
                nextTopic: 'table',
                nextTables: nextT,
                nextMaxMult: maxMultiplier,
                nextMin: rangeMin,
                nextMax: rangeMax,
                nextOrder: order,
                nextMixedCount: mixedCount,
              });
            }}
            className="min-h-[44px] px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap"
          >
            <span>
              {lang === 'bn'
                ? `পরের নামতা (${f(singleTable + 1)})`
                : `Next Table (${f(singleTable + 1)})`}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}

        <button
          type="button"
          onClick={() => setPhase('setup')}
          className="min-h-[44px] px-4 rounded-xl text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors whitespace-nowrap"
        >
          {lang === 'bn' ? 'বিষয় বদলান' : 'Change Topic'}
        </button>
      </div>
    </section>
  );
};
