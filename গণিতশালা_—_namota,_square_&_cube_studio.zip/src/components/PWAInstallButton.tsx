import React, { useState } from 'react';
import { CheckCircle2, Download, Share, Smartphone, WifiOff, X } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';
import { Lang } from '../utils/math';

interface PWAInstallButtonProps {
  lang: Lang;
  variant?: 'full' | 'compact';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  lang,
  variant = 'full',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  // Suppress install prompt when already running in installed standalone app mode
  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuide(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className={
          variant === 'full'
            ? 'w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-sky-700 hover:bg-sky-800 active:scale-[0.98] text-white text-sm font-medium inline-flex items-center justify-center gap-2 transition-all whitespace-nowrap'
            : 'h-8 px-2.5 rounded-lg bg-sky-700 hover:bg-sky-800 active:scale-[0.98] text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-all whitespace-nowrap shrink-0'
        }
      >
        <Download className={variant === 'full' ? 'w-4 h-4 shrink-0' : 'w-3.5 h-3.5 shrink-0'} />
        <span>
          {variant === 'compact'
            ? lang === 'bn'
              ? 'ইনস্টল'
              : 'Install'
            : lang === 'bn'
              ? 'অ্যাপ ইনস্টল করুন'
              : 'Install App'}
        </span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-xs p-0 sm:p-4"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl bg-white p-6 shadow-xl border border-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto mb-4 sm:hidden" />

            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src="/icon.svg"
                  alt="গণিতশালা"
                  className="w-11 h-11 rounded-xl shrink-0"
                />
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {lang === 'bn'
                      ? 'ফোনে অ্যাপ হিসেবে ইনস্টল করুন'
                      : 'Install as a Native App'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {lang === 'bn'
                      ? 'অফলাইনেও সম্পূর্ণ কাজ করবে'
                      : 'Works completely offline on your home screen'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label={lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
                className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-5 space-y-3 text-sm text-slate-700 leading-relaxed">
              {isIOS ? (
                <>
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <Share className="w-4 h-4 text-sky-700 mt-0.5 shrink-0" />
                    <div>
                      <strong className="text-slate-900">
                        {lang === 'bn' ? '১. Share বাটনে ট্যাপ করুন' : '1. Tap the Share button'}
                      </strong>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {lang === 'bn'
                          ? 'Safari ব্রাউজারের নিচের টুলবারে Share আইকনে ক্লিক করুন।'
                          : 'Tap the Share icon at the bottom of Safari.'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <Smartphone className="w-4 h-4 text-sky-700 mt-0.5 shrink-0" />
                    <div>
                      <strong className="text-slate-900">
                        {lang === 'bn'
                          ? '২. Add to Home Screen নির্বাচন করুন'
                          : '2. Tap Add to Home Screen'}
                      </strong>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {lang === 'bn'
                          ? 'নিচে স্ক্রল করে "Add to Home Screen" ট্যাপ করলেই ফোনে অ্যাপ আইকন চলে আসবে।'
                          : 'Scroll down and tap "Add to Home Screen" to install the app icon.'}
                      </p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <Smartphone className="w-4 h-4 text-sky-700 mt-0.5 shrink-0" />
                    <div>
                      <strong className="text-slate-900">
                        {lang === 'bn'
                          ? 'Android / Chrome-এ ইনস্টল'
                          : 'Install on Android / Chrome'}
                      </strong>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {lang === 'bn'
                          ? 'ব্রাউজারের উপরের মেনু (⋮) ট্যাপ করে "Install app" অথবা "Add to Home screen" সিলেক্ট করুন।'
                          : 'Open the browser menu (⋮) and tap "Install app" or "Add to Home screen".'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700 mt-0.5 shrink-0" />
                    <div>
                      <strong className="text-slate-900">
                        {lang === 'bn'
                          ? 'ডাইরেক্ট লিংকে খুলুন'
                          : 'Open Full App URL'}
                      </strong>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {lang === 'bn'
                          ? 'অ্যাপটি সরাসরি ব্রাউজার ট্যাবে খুললে এক ক্লিকেই ইনস্টল পপআপ দেখাবে।'
                          : 'Opening this app directly in a browser tab enables the one-tap native install prompt.'}
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-5 w-full min-h-[44px] rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium transition-colors"
            >
              {lang === 'bn' ? 'বুঝেছি' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC<{ lang: Lang }> = ({ lang }) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 md:bottom-5 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-medium text-white shadow-lg"
    >
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>
        {lang === 'bn'
          ? 'অফলাইন মোড — অ্যাপটি ইন্টারনেট ছাড়াই চলছে'
          : 'Offline Mode — Running from saved app cache'}
      </span>
    </div>
  );
};
