import React, { useMemo, useState } from 'react';
import { Play } from 'lucide-react';
import { DigitStyle, Lang, formatNumber } from '../utils/math';

interface SinglePowerViewProps {
  mode: 'square' | 'cube';
  lang: Lang;
  digitStyle: DigitStyle;
  onStartQA: (mode: 'square' | 'cube', min: number, max: number) => void;
}

type RangeKey = '1-20' | '21-40' | '41-60' | '61-80' | '81-100' | 'all';

const RANGES: { key: RangeKey; min: number; max: number }[] = [
  { key: '1-20', min: 1, max: 20 },
  { key: '21-40', min: 21, max: 40 },
  { key: '41-60', min: 41, max: 60 },
  { key: '61-80', min: 61, max: 80 },
  { key: '81-100', min: 81, max: 100 },
  { key: 'all', min: 1, max: 100 },
];

export const SinglePowerView: React.FC<SinglePowerViewProps> = ({
  mode,
  lang,
  digitStyle,
  onStartQA,
}) => {
  const [range, setRange] = useState<RangeKey>('1-20');

  const f = (n: number | string, commas = false) =>
    formatNumber(n, digitStyle, commas);

  const isSquare = mode === 'square';
  const activeRangeObj = RANGES.find((r) => r.key === range) ?? RANGES[0];

  const numbers = useMemo(() => {
    return Array.from(
      { length: activeRangeObj.max - activeRangeObj.min + 1 },
      (_, i) => activeRangeObj.min + i
    );
  }, [activeRangeObj]);

  return (
    <div className="max-w-3xl mx-auto">
      <section className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6">
        {/* Compact Mobile-First Header */}
        <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
              <span>
                {isSquare
                  ? lang === 'bn'
                    ? 'বর্গ'
                    : 'Squares'
                  : lang === 'bn'
                    ? 'ঘন'
                    : 'Cubes'}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {f(1)}–{f(100)}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-0.5 truncate">
              {isSquare
                ? lang === 'bn'
                  ? 'বর্গ তালিকা (n²)'
                  : 'Squares (n²)'
                : lang === 'bn'
                  ? 'ঘন তালিকা (n³)'
                  : 'Cubes (n³)'}
            </h1>
          </div>

          <button
            type="button"
            onClick={() =>
              onStartQA(mode, activeRangeObj.min, activeRangeObj.max)
            }
            className="min-h-[40px] px-3.5 sm:px-4 rounded-xl bg-sky-700 hover:bg-sky-800 active:scale-[0.98] text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'প্রশ্ন-উত্তর' : 'Start Q&A'}</span>
          </button>
        </div>

        {/* Symmetrical Range Grid */}
        <div className="py-3.5 border-b border-slate-100">
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 p-1 bg-slate-100 rounded-xl">
            {RANGES.map((r) => (
              <button
                key={r.key}
                type="button"
                onClick={() => setRange(r.key)}
                className={`py-1.5 px-1.5 text-[11px] sm:text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  range === r.key
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {r.key === 'all'
                  ? lang === 'bn'
                    ? 'সব'
                    : 'All'
                  : `${f(r.min)}–${f(r.max)}`}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile-Optimized 2-Column Stacked Typographic Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 pt-3.5 max-h-[65vh] overflow-y-auto pr-0.5">
          {numbers.map((n) => {
            const val = isSquare ? n * n : n * n * n;
            const isLargeCube = !isSquare && val >= 100000;

            return (
              <div
                key={n}
                className="min-h-[68px] px-3.5 py-2.5 rounded-xl border border-slate-200/80 bg-slate-50/55 flex flex-col justify-between text-left"
              >
                <div className="text-xs font-semibold text-sky-700 tabular-math">
                  {f(n)}
                  <sup className="ml-0.5 font-bold">
                    {isSquare ? f(2) : f(3)}
                  </sup>
                </div>

                <span
                  className={`font-bold text-slate-900 tabular-math mt-0.5 ${
                    isLargeCube
                      ? 'text-[15px] sm:text-base'
                      : 'text-lg sm:text-xl'
                  }`}
                >
                  {f(val, true)}
                </span>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
