export type Lang = 'bn' | 'en';
export type DigitStyle = 'bn' | 'en';
export type AppTab = 'tables' | 'square' | 'cube' | 'qa';

export type QuestionKind = 'table' | 'square' | 'cube';

export interface MathQuestion {
  id: string;
  kind: QuestionKind;
  a: number;
  b?: number; // multiplier for table questions
  answer: number;
  options: number[];
}

export interface QuizRecord {
  id: string;
  dateISO: string;
  topic: 'table' | 'square' | 'cube' | 'mixed';
  mode: 'mcq' | 'type';
  total: number;
  correct: number;
  accuracy: number;
  avgSeconds: number;
  rangeLabel: string;
}

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export function toBengaliDigits(value: number | string): string {
  return String(value).replace(/\d/g, (d) => BENGALI_DIGITS[Number(d)]);
}

export function normalizeDigits(input: string): string {
  let out = '';
  for (const ch of input) {
    const bnIdx = BENGALI_DIGITS.indexOf(ch);
    if (bnIdx !== -1) {
      out += String(bnIdx);
    } else if (ch >= '0' && ch <= '9') {
      out += ch;
    }
  }
  return out;
}

export function formatNumber(
  value: number | string,
  digitStyle: DigitStyle,
  withCommas = false
): string {
  const formatted =
    withCommas && typeof value === 'number'
      ? value.toLocaleString('en-IN')
      : String(value);
  return digitStyle === 'bn' ? toBengaliDigits(formatted) : formatted;
}

export function getMentalMathBreakdown(
  a: number,
  b: number,
  lang: Lang,
  digitStyle: DigitStyle
): { formula: string; steps: string; tip: string } {
  const f = (n: number) => formatNumber(n, digitStyle);
  const product = a * b;

  if (a <= 10) {
    const repeated = Array.from({ length: Math.min(b, 5) }, () => f(a)).join(' + ');
    const suffix = b > 5 ? ` + … (${f(b)} ${lang === 'bn' ? 'বার' : 'times'})` : '';
    return {
      formula: `${f(a)} × ${f(b)} = ${f(product)}`,
      steps: `${repeated}${suffix} = ${f(product)}`,
      tip:
        lang === 'bn'
          ? `${f(a)} সংখ্যাটি ${f(b)} বার যোগ করলে ${f(product)} পাওয়া যায়।`
          : `Adding ${f(a)} a total of ${f(b)} times gives ${f(product)}.`,
    };
  }

  const tens = Math.floor(a / 10) * 10;
  const ones = a % 10;

  if (ones === 0) {
    const base = a / 10;
    return {
      formula: `${f(a)} × ${f(b)} = (${f(base)} × ${f(b)}) × ${f(10)}`,
      steps: `${f(base * b)} × ${f(10)} = ${f(product)}`,
      tip:
        lang === 'bn'
          ? `শেষে শূন্য থাকলে আগে ${f(base)} × ${f(b)} = ${f(base * b)} বের করে ডানে একটি ${f(0)} বসিয়ে দিন।`
          : `Multiply ${f(base)} × ${f(b)} = ${f(base * b)}, then append a zero.`,
    };
  }

  // If ones is 8 or 9, subtraction from next ten is often faster
  if (ones >= 8) {
    const nextTen = tens + 10;
    const diff = nextTen - a;
    const highPart = nextTen * b;
    const subPart = diff * b;
    return {
      formula: `${f(a)} × ${f(b)} = (${f(nextTen)} − ${f(diff)}) × ${f(b)}`,
      steps: `${f(highPart)} − ${f(subPart)} = ${f(product)}`,
      tip:
        lang === 'bn'
          ? `${f(a)} সংখ্যাটি ${f(nextTen)}-এর কাছাকাছি, তাই ${f(highPart)} থেকে ${f(subPart)} বিয়োগ করলে দ্রুত উত্তর মেলে।`
          : `${f(a)} is close to ${f(nextTen)}, so subtract ${f(subPart)} from ${f(highPart)} for fast mental math.`,
    };
  }

  const leftPart = tens * b;
  const rightPart = ones * b;
  return {
    formula: `${f(a)} × ${f(b)} = (${f(tens)} + ${f(ones)}) × ${f(b)}`,
    steps: `${f(leftPart)} + ${f(rightPart)} = ${f(product)}`,
    tip:
      lang === 'bn'
        ? `দশক ও একক আলাদা করে গুণ করে যোগ করুন: ${f(leftPart)} + ${f(rightPart)} = ${f(product)}।`
        : `Split into tens and ones, multiply separately, then add: ${f(leftPart)} + ${f(rightPart)} = ${f(product)}.`,
  };
}

export function getSquareTrick(
  n: number,
  lang: Lang,
  digitStyle: DigitStyle
): string {
  const f = (v: number) => formatNumber(v, digitStyle, true);
  const sq = n * n;
  if (n % 10 === 5) {
    const prefix = Math.floor(n / 10);
    const next = prefix + 1;
    return lang === 'bn'
      ? `শেষে ${f(5)} থাকলে: ${f(prefix)} × ${f(next)} = ${f(prefix * next)}, এরপর পাশে ${f(25)} বসালেই ${f(sq)}।`
      : `Ends in 5 rule: multiply ${f(prefix)} × ${f(next)} = ${f(prefix * next)}, then append 25 to get ${f(sq)}.`;
  }
  if (n % 10 === 0) {
    const base = n / 10;
    return lang === 'bn'
      ? `${f(base)}² = ${f(base * base)}, তার ডানে দুটি শূন্য (${f(0)}${f(0)}) বসালেই ${f(sq)}।`
      : `Square ${f(base)} to get ${f(base * base)}, then append two zeros for ${f(sq)}.`;
  }
  const tens = Math.floor(n / 10) * 10;
  const ones = n % 10;
  if (tens > 0) {
    return lang === 'bn'
      ? `(${f(tens)} + ${f(ones)})² = ${f(tens * tens)} + ${f(2 * tens * ones)} + ${f(ones * ones)} = ${f(sq)}।`
      : `(${f(tens)} + ${f(ones)})² = ${f(tens * tens)} + ${f(2 * tens * ones)} + ${f(ones * ones)} = ${f(sq)}.`;
  }
  return lang === 'bn'
    ? `${f(n)} × ${f(n)} = ${f(sq)}।`
    : `${f(n)} × ${f(n)} = ${f(sq)}.`;
}

function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function generateDistractors(
  kind: QuestionKind,
  a: number,
  b: number | undefined,
  answer: number
): number[] {
  const candidates = new Set<number>();

  if (kind === 'table' && b !== undefined) {
    const offsets = [a, -a, b, -b, 10, -10, 2, -2, 1, -1, 2 * a, -2 * a];
    for (const off of offsets) {
      const val = answer + off;
      if (val > 0 && val !== answer) {
        candidates.add(val);
      }
    }
  } else if (kind === 'square') {
    const neighborBases = [a - 2, a - 1, a + 1, a + 2];
    for (const nb of neighborBases) {
      if (nb > 0) candidates.add(nb * nb);
    }
    const offsets = [10, -10, 20, -20, 100, -100, a, -a, 2, -2];
    for (const off of offsets) {
      const val = answer + off;
      if (val > 0 && val !== answer) candidates.add(val);
    }
  } else {
    // cube
    const neighborBases = [a - 1, a + 1, a - 2, a + 2];
    for (const nb of neighborBases) {
      if (nb > 0) candidates.add(nb * nb * nb);
    }
    const step = Math.max(10, Math.round(answer * 0.04));
    const offsets = [step, -step, 100, -100, 10, -10, a * a, -a * a];
    for (const off of offsets) {
      const val = answer + off;
      if (val > 0 && val !== answer) candidates.add(val);
    }
  }

  candidates.delete(answer);
  const picked = shuffleArray(Array.from(candidates)).slice(0, 3);

  let fallbackOffset = 3;
  while (picked.length < 3) {
    const val = answer + fallbackOffset;
    if (val > 0 && val !== answer && !picked.includes(val)) {
      picked.push(val);
    }
    fallbackOffset += 2;
  }

  return shuffleArray([answer, ...picked]);
}

export function buildPracticeQuestions(params: {
  kind: QuestionKind;
  tables: number[];
  maxMultiplier: number;
  powerMin: number;
  powerMax: number;
  order: 'sequential' | 'shuffled';
  count?: number;
}): MathQuestion[] {
  const { kind, tables, maxMultiplier, powerMin, powerMax, order, count } = params;
  const list: MathQuestion[] = [];

  if (kind === 'table') {
    const sortedTables = [...tables].sort((x, y) => x - y);
    for (const t of sortedTables) {
      for (let m = 1; m <= maxMultiplier; m++) {
        const answer = t * m;
        list.push({
          id: `t-${t}-${m}-${Math.random().toString(36).slice(2, 7)}`,
          kind: 'table',
          a: t,
          b: m,
          answer,
          options: generateDistractors('table', t, m, answer),
        });
      }
    }
  } else {
    const min = Math.max(1, Math.min(powerMin, powerMax));
    const max = Math.min(100, Math.max(powerMin, powerMax));
    for (let n = min; n <= max; n++) {
      const answer = kind === 'square' ? n * n : n * n * n;
      list.push({
        id: `${kind}-${n}-${Math.random().toString(36).slice(2, 7)}`,
        kind,
        a: n,
        answer,
        options: generateDistractors(kind, n, undefined, answer),
      });
    }
  }

  const ordered = order === 'shuffled' ? shuffleArray(list) : list;
  return count ? ordered.slice(0, count) : ordered;
}

export function buildQuizQuestions(params: {
  topic: 'table' | 'square' | 'cube' | 'mixed';
  tableMin: number;
  tableMax: number;
  maxMultiplier: number;
  squareMin: number;
  squareMax: number;
  cubeMin: number;
  cubeMax: number;
  count: number;
}): MathQuestion[] {
  const {
    topic,
    tableMin,
    tableMax,
    maxMultiplier,
    squareMin,
    squareMax,
    cubeMin,
    cubeMax,
    count,
  } = params;

  const pool: MathQuestion[] = [];
  const seenKeys = new Set<string>();

  const addQuestion = (kind: QuestionKind, a: number, b?: number) => {
    const key = `${kind}-${a}-${b ?? ''}`;
    if (seenKeys.has(key)) return false;
    seenKeys.add(key);
    const answer =
      kind === 'table' && b !== undefined
        ? a * b
        : kind === 'square'
          ? a * a
          : a * a * a;
    pool.push({
      id: `${key}-${Math.random().toString(36).slice(2, 6)}`,
      kind,
      a,
      b,
      answer,
      options: generateDistractors(kind, a, b, answer),
    });
    return true;
  };

  const randInt = (min: number, max: number) =>
    Math.floor(Math.random() * (max - min + 1)) + min;

  let attempts = 0;
  while (pool.length < count && attempts < count * 25) {
    attempts++;
    let chosenKind: QuestionKind;
    if (topic === 'mixed') {
      const roll = pool.length % 3;
      chosenKind = roll === 0 ? 'table' : roll === 1 ? 'square' : 'cube';
    } else {
      chosenKind = topic;
    }

    if (chosenKind === 'table') {
      const a = randInt(Math.min(tableMin, tableMax), Math.max(tableMin, tableMax));
      const b = randInt(1, maxMultiplier);
      addQuestion('table', a, b);
    } else if (chosenKind === 'square') {
      const a = randInt(Math.min(squareMin, squareMax), Math.max(squareMin, squareMax));
      addQuestion('square', a);
    } else {
      const a = randInt(Math.min(cubeMin, cubeMax), Math.max(cubeMin, cubeMax));
      addQuestion('cube', a);
    }
  }

  // Fallback if range is narrower than requested question count
  while (pool.length < count) {
    const chosenKind: QuestionKind =
      topic === 'mixed' ? 'table' : topic;
    if (chosenKind === 'table') {
      const a = randInt(Math.min(tableMin, tableMax), Math.max(tableMin, tableMax));
      const b = randInt(1, maxMultiplier);
      const answer = a * b;
      pool.push({
        id: `fb-t-${a}-${b}-${pool.length}`,
        kind: 'table',
        a,
        b,
        answer,
        options: generateDistractors('table', a, b, answer),
      });
    } else if (chosenKind === 'square') {
      const a = randInt(Math.min(squareMin, squareMax), Math.max(squareMin, squareMax));
      const answer = a * a;
      pool.push({
        id: `fb-s-${a}-${pool.length}`,
        kind: 'square',
        a,
        answer,
        options: generateDistractors('square', a, undefined, answer),
      });
    } else {
      const a = randInt(Math.min(cubeMin, cubeMax), Math.max(cubeMin, cubeMax));
      const answer = a * a * a;
      pool.push({
        id: `fb-c-${a}-${pool.length}`,
        kind: 'cube',
        a,
        answer,
        options: generateDistractors('cube', a, undefined, answer),
      });
    }
  }

  return shuffleArray(pool);
}

const PRACTICED_TABLES_KEY = 'gonitshala_practiced_tables_v1';
const QUIZ_HISTORY_KEY = 'gonitshala_quiz_history_v1';

export function loadPracticedTables(): number[] {
  try {
    const raw = localStorage.getItem(PRACTICED_TABLES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((n) => typeof n === 'number') : [];
  } catch {
    return [];
  }
}

export function savePracticedTables(tables: number[]): number[] {
  const existing = new Set(loadPracticedTables());
  for (const t of tables) existing.add(t);
  const merged = Array.from(existing).sort((a, b) => a - b);
  try {
    localStorage.setItem(PRACTICED_TABLES_KEY, JSON.stringify(merged));
  } catch {
    // ignore storage quota errors
  }
  return merged;
}

export function loadQuizHistory(): QuizRecord[] {
  try {
    const raw = localStorage.getItem(QUIZ_HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveQuizRecord(record: QuizRecord): QuizRecord[] {
  const existing = loadQuizHistory();
  const updated = [record, ...existing].slice(0, 12);
  try {
    localStorage.setItem(QUIZ_HISTORY_KEY, JSON.stringify(updated));
  } catch {
    // ignore storage quota errors
  }
  return updated;
}

export function clearQuizHistory(): void {
  try {
    localStorage.removeItem(QUIZ_HISTORY_KEY);
  } catch {
    // ignore
  }
}
