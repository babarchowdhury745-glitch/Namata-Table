import { useState } from 'react';
import {
  Box,
  Grid3x3,
  HelpCircle,
  Square,
} from 'lucide-react';
import { TablesView } from './components/TablesView';
import { SinglePowerView } from './components/SinglePowerView';
import { QAPreset, QAView } from './components/QAView';
import {
  OfflineIndicator,
  PWAInstallButton,
} from './components/PWAInstallButton';
import {
  AppTab,
  DigitStyle,
  Lang,
  formatNumber,
  loadPracticedTables,
  savePracticedTables,
} from './utils/math';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('tables');
  const [lang, setLang] = useState<Lang>('bn');
  const [digitStyle, setDigitStyle] = useState<DigitStyle>('en');
  const [selectedTable, setSelectedTable] = useState<number>(12);
  const [practicedTables, setPracticedTables] = useState<number[]>(() =>
    loadPracticedTables()
  );
  const [qaPreset, setQaPreset] = useState<QAPreset | null>(null);

  const f = (n: number | string) => formatNumber(n, digitStyle);

  const handleMarkTablesPracticed = (tables: number[]) => {
    const updated = savePracticedTables(tables);
    setPracticedTables(updated);
  };

  const handleStartTableQA = (tableNum: number, maxMultiplier: number) => {
    setQaPreset({
      topic: 'table',
      tables: [tableNum],
      maxMultiplier,
      autoStart: true,
      nonce: Date.now(),
    });
    setActiveTab('qa');
  };

  const handleStartPowerQA = (
    mode: 'square' | 'cube',
    min: number,
    max: number
  ) => {
    setQaPreset({
      topic: mode,
      rangeMin: min,
      rangeMax: max,
      autoStart: true,
      nonce: Date.now(),
    });
    setActiveTab('qa');
  };

  // Exact 4 user-requested options: Namta, Square, Cube, Q&A
  const navItems: {
    id: AppTab;
    bn: string;
    en: string;
    shortBn: string;
    shortEn: string;
    icon: typeof Grid3x3;
  }[] = [
    {
      id: 'tables',
      bn: `নামতা (${f(1)}–${f(50)})`,
      en: `Namta (${f(1)}–${f(50)})`,
      shortBn: 'নামতা',
      shortEn: 'Namta',
      icon: Grid3x3,
    },
    {
      id: 'square',
      bn: `বর্গ (${f(1)}–${f(100)})`,
      en: `Square (${f(1)}–${f(100)})`,
      shortBn: 'বর্গ',
      shortEn: 'Square',
      icon: Square,
    },
    {
      id: 'cube',
      bn: `ঘন (${f(1)}–${f(100)})`,
      en: `Cube (${f(1)}–${f(100)})`,
      shortBn: 'ঘন',
      shortEn: 'Cube',
      icon: Box,
    },
    {
      id: 'qa',
      bn: 'প্রশ্ন-উত্তর',
      en: 'Q&A Test',
      shortBn: 'প্রশ্ন-উত্তর',
      shortEn: 'Q&A',
      icon: HelpCircle,
    },
  ];

  const activeNav = navItems.find((item) => item.id === activeTab) ?? navItems[0];

  return (
    <div className="min-h-screen md:h-screen md:overflow-hidden flex flex-col md:flex-row bg-slate-50 text-slate-900">
      {/* Desktop Native App Sidebar Rail */}
      <aside className="hidden md:flex md:w-64 lg:w-68 shrink-0 flex-col bg-white border-r border-slate-200 select-none">
        <div className="h-16 px-5 flex items-center gap-3 border-b border-slate-200">
          <img
            src="/icon.svg"
            alt={lang === 'bn' ? 'গণিতশালা অ্যাপ' : 'Gonitshala App'}
            className="w-9 h-9 rounded-xl shrink-0"
          />
          <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap truncate">
            {lang === 'bn' ? 'গণিতশালা' : 'Gonitshala'}
          </span>
        </div>

        {/* 4 App Tabs */}
        <nav
          aria-label={lang === 'bn' ? 'অ্যাপ নেভিগেশন' : 'App Navigation'}
          className="flex-1 p-3 space-y-1 overflow-y-auto"
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full min-h-[44px] px-3.5 py-2.5 rounded-xl text-sm font-medium flex items-center gap-3 transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-sky-50 text-sky-800 font-semibold'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon
                  className={`w-5 h-5 shrink-0 ${
                    active ? 'text-sky-700' : 'text-slate-500'
                  }`}
                />
                <span className="truncate">
                  {lang === 'bn' ? item.bn : item.en}
                </span>
              </button>
            );
          })}

          {/* Progress Snapshot */}
          <div className="mt-6 mx-1 pt-5 border-t border-slate-200">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2 tabular-bengali">
              <span>{lang === 'bn' ? 'অনুশীলন অগ্রগতি' : 'Table Mastery'}</span>
              <span className="font-semibold text-slate-800">
                {f(practicedTables.length)}/{f(50)}
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-sky-600 transition-all duration-200"
                style={{
                  width: `${(practicedTables.length / 50) * 100}%`,
                }}
              />
            </div>
          </div>
        </nav>

        {/* App Preferences & Install Trigger */}
        <div className="p-4 border-t border-slate-200 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div
              className="flex items-center p-0.5 bg-slate-100 rounded-lg"
              role="group"
              aria-label="Language"
            >
              <button
                type="button"
                onClick={() => setLang('bn')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  lang === 'bn'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  lang === 'en'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                EN
              </button>
            </div>

            <div
              className="flex items-center p-0.5 bg-slate-100 rounded-lg"
              role="group"
              aria-label="Digits"
            >
              <button
                type="button"
                onClick={() => setDigitStyle('bn')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  digitStyle === 'bn'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                ১২৩
              </button>
              <button
                type="button"
                onClick={() => setDigitStyle('en')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors tabular-math ${
                  digitStyle === 'en'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                123
              </button>
            </div>
          </div>

          <PWAInstallButton lang={lang} variant="full" />
        </div>
      </aside>

      {/* Mobile Compact App Top Bar */}
      <header className="md:hidden sticky top-0 z-30 pt-safe bg-white/95 backdrop-blur-md border-b border-slate-200 select-none">
        <div className="h-13 px-3.5 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src="/icon.svg"
              alt={lang === 'bn' ? 'গণিতশালা' : 'Gonitshala'}
              className="w-7 h-7 rounded-lg shrink-0"
            />
            <div className="min-w-0 leading-tight">
              <div className="text-[15px] font-bold text-slate-900 truncate">
                {lang === 'bn' ? 'গণিতশালা' : 'Gonitshala'}
              </div>
              <div className="text-[11px] font-medium text-slate-500 truncate">
                {lang === 'bn' ? activeNav.bn : activeNav.en}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Scrollable Main App Viewport */}
      <main className="flex-1 md:overflow-y-auto">
        <div className="max-w-5xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-3.5 sm:py-6 pb-22 md:pb-10">
          {activeTab === 'tables' && (
            <TablesView
              lang={lang}
              digitStyle={digitStyle}
              selectedTable={selectedTable}
              onSelectTable={setSelectedTable}
              practicedTables={practicedTables}
              onPracticeTable={handleStartTableQA}
            />
          )}

          {activeTab === 'square' && (
            <SinglePowerView
              mode="square"
              lang={lang}
              digitStyle={digitStyle}
              onStartQA={handleStartPowerQA}
            />
          )}

          {activeTab === 'cube' && (
            <SinglePowerView
              mode="cube"
              lang={lang}
              digitStyle={digitStyle}
              onStartQA={handleStartPowerQA}
            />
          )}

          {activeTab === 'qa' && (
            <QAView
              lang={lang}
              digitStyle={digitStyle}
              preset={qaPreset}
              onMarkTablesPracticed={handleMarkTablesPracticed}
            />
          )}
        </div>
      </main>

      {/* Mobile Native Bottom Tab Bar (4 Options: Namta, Square, Cube, Q&A) */}
      <nav
        aria-label={lang === 'bn' ? 'নিচের ট্যাব বার' : 'Bottom Navigation'}
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe select-none"
      >
        <div className="grid grid-cols-4 h-[60px]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`relative min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors active:scale-95 ${
                  active ? 'text-sky-700' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-sky-700"
                  />
                )}
                <Icon className="w-5 h-5" strokeWidth={active ? 2.3 : 1.8} />
                <span
                  className={`text-[11px] leading-none whitespace-nowrap ${
                    active ? 'font-bold' : 'font-medium'
                  }`}
                >
                  {lang === 'bn' ? item.shortBn : item.shortEn}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Offline Status Toast */}
      <OfflineIndicator lang={lang} />
    </div>
  );
}
